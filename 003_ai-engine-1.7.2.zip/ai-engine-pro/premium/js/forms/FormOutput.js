// React & Vendor Libs
const { useMemo } = wp.element;
import Markdown from 'markdown-to-jsx';

// AI Engine
import { BlinkingCursor } from '@app/helpers';

const FormOutput = (props) => {
  const { content, error, isStreaming } = props;
  const isError = !!error;
  let data = isError ? error : content;

  // Ensure this is encloded markdown
  const matches = (data.match(/```/g) || []).length;
  if (matches % 2 !== 0) { // if count is odd
    data += "\n```"; // add ``` at the end
  }
  else if (isStreaming) {
    data += "<BlinkingCursor />";
  }

  const classes = useMemo(() => {
    const baseClass = ['mwai-form-output'];
    if (error) {
      baseClass.push('mwai-error');
    }
    return baseClass;
  }, [error]);
  
  const markdownOptions = useMemo(() => {
    const options = {
      wrapper: 'div',
      forceWrapper: true,
      overrides: {
        BlinkingCursor: { component: BlinkingCursor },
        a: {
          props: {
            target: "_blank",
          },
        },
      }
    };
    return options;
  }, []);

  return (
    <Markdown options={markdownOptions} className={classes.join(' ')} children={data} />
  );
}

export default FormOutput;