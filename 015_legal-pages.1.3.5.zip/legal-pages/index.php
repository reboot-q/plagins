<?php
// speak only when it is beneficial.

