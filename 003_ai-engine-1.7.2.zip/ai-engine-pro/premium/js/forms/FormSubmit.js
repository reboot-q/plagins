// React & Vendor Libs
const { useEffect, useRef, useState, useMemo } = wp.element;

// AI Engine
import { mwaiHandleRes, mwaiFetch, randomStr } from '@app/helpers';
import FormOutput from './FormOutput';

const FormSubmit = (props) => {
  const { system, params, theme } = props;
  const [ isLoading, setIsLoading ] = useState(false);
  const [ isValid,  setIsValid ] = useState(false);
  const [ clientId, setClientId ] = useState(randomStr());
  const [ fields, setFields ] = useState({});
  const refSubmit = useRef(null);
  const refContainer = useRef(null);
  const [ serverReply, setServerReply ] = useState();

  // System Params
  const { id,  stream = false, formId, sessionId, contextId, restNonce, restUrl, debugMode } = system;
  
  // Front Params
  const { label, outputElement, inputs } = params;

  useEffect(() => {
    const container = refSubmit.current.closest('.mwai-form-container');
    if (!container) {
      alert("The 'Submit' is not embeddded in a 'Container'.");
    }
    if (!inputs) {
      alert("The 'Inputs' are not defined.");
      return;
    }
    refContainer.current = container;
    const inputElements = [];
    inputs.selectors.forEach(selector => {
      const element = document.querySelector(selector);
      inputElements.push({ selector, element });
    });
    inputs.fields.forEach(field => {
      const element = refContainer.current.querySelector(`fieldset[data-form-name='${field}']`);
      if (!element) {
        alert(`The 'Input Field' was not found (${field}).`);
        return;
      }
      const subType = element.getAttribute('data-form-type');
      const required = element.getAttribute('data-form-required') === 'true';
      inputElements.push({ field, subType, element, required });
    });

    inputElements.forEach(inputElement => {
      onInputElementChanged(inputElement);
      inputElement.element.addEventListener('change', () => { onInputElementChanged(inputElement) });
      inputElement.element.addEventListener('keyup', () => { onInputElementChanged(inputElement) });
      if (inputElement.selector) {
        const observer = new MutationObserver(() => { onInputElementChanged(inputElement) });
        observer.observe(inputElement.element, { childList: true, subtree: true });
      }
      else {
        
      }
    });
  }, [inputs]);

  useEffect(() => {
    const output = refContainer.current.querySelector(outputElement);
    if (!serverReply) { return; }
    if (!output) { alert(`The 'Output' was not found (${outputElement ?? 'N/A'}).`); return; }
    const { success, reply, message } = serverReply;
    if (success) {
      ReactDOM.render(<FormOutput content={reply} isStreaming={isLoading && stream} />, output);
    }
    else {
      ReactDOM.render(<FormOutput error={message} isStreaming={isLoading && stream} />, output);
    }
  }, [isLoading, stream, serverReply]);

  // Update the content of the fields.
  const onInputElementChanged = async (inputElement) => {
    const key = inputElement.field ?? inputElement.selector;
    const currentVal = fields[key] ?? null;
    let newVal = null;
    let isValid = true;
    
    if (inputElement.field && inputElement.subType === 'checkbox') {
      const checkboxes = [...inputElement.element.querySelectorAll('input[type="checkbox"]')];
      newVal = checkboxes.filter(checkbox => checkbox.checked).map(checkbox => checkbox.value);
    }
    else if (inputElement.field) {
      const input = inputElement.element.querySelector(inputElement.subType);
      newVal = input.value;
      isValid = !(inputElement.required && (!newVal || newVal === ''));
    }
    else if (inputElement.selector) {
      newVal = inputElement.element.textContent.trim();
    }
    const hasChanges = currentVal !== newVal;
    if (hasChanges) {
      fields[key] = newVal;
      setFields({ ...fields });
    }
    setIsValid(isValid);
  };

  const onSubmitClick = async () => {
    setIsLoading(true);
    setServerReply({ success: true, reply: '' });

    const body = {
      id: id, formId: formId,
      session: sessionId, clientId: clientId, contextId: contextId, stream,
      fields
    };

    try {
      if (debugMode) { console.log('[FORMS] OUT: ', body); }
      const streamCallback = !stream ? null : (content) => {
        setServerReply({ success: true, reply: content });
      };

      // Let's perform the request. The mwaiHandleRes will handle the complexity of response.
      const res = await mwaiFetch(`${restUrl}/mwai-ui/v1/forms/submit`, body, restNonce, stream);
      const data = await mwaiHandleRes(res, streamCallback, debugMode ? "FORMS" : null);
      setServerReply(data);
      console.log('[FORMS] IN: ', data)
    }
    catch (err) {
      console.error("An error happened in the handling of the forms response.", { err });
    }
    finally {
      setIsLoading(false);
    }
  }

  const baseClasses = useMemo(() => {
    const classes = ['mwai-form-submit'];
    if (isLoading) {
      classes.push('mwai-loading');
    }
    return classes;
  }, [isLoading]);

  return (
    <div ref={refSubmit} className={baseClasses.join(' ')}>
      <button id={id} disabled={!isValid || isLoading} onClick={onSubmitClick}><span>{label}</span></button>
    </div>
  );
};

export default FormSubmit;
