<?php 
 if( ! empty( $_GET['page'] ) && 'legal-page-support' == $_GET['page'] ) {
?>
    <div class="legal-page-support wplp-support-card wplp-container-sm wplp-ml-10 wplp-mt-30">
        <div class="legal-page-support-container">
            <div class="legal-page-support__left">
                <div class="legal-page-help wplp-support-card wplp-container-sm wplp-mt-30">
                    <div class="wplp-page-wrapper wplp-d-block wplp-p-0">
                        <h1 class="wplp-support-card-title">Need Help?</h1>
                        <div class="wplp-support-card-content">
                            <p class="wplp-mb-20">Need help? Get special care from our dedicated support team.</p>
                            <a href="https://wpwax.com/contact/" class="wplp-btn-primary">Get Support</a>
                        </div>
                    </div>
                </div> <!--ends .tab-pane   #Support-->
            </div>
        </div>



    </div> <!--ends .tab-pane   #Support-->
<?php } ?>

